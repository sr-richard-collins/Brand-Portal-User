const Preloader = () => <div className="preloader-progress-bar">
    <div className="progress-value" />
  </div>;
export default Preloader;